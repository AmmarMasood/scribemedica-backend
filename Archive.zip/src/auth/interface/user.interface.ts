export interface IUser {
  email: string;
  roles: string[];
  type: string;
  userId: string;
}
